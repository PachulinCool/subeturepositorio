from setuptools import setup,find_packages

setup(
    name= 'repositos',
    version= '0.0.1',
    license= 'MIT',
    description= 'subir',
    install_requires=['Tkinyer','subproses','os'],
    packages=find_packages(),
    url= 'https://github.com/PachulinCool/subirrepositorio',

)